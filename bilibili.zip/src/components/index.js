import nav from './vue-sortable-nav'

export default nav